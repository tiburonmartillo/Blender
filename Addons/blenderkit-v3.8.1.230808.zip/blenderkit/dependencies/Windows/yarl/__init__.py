from ._url import URL, cache_clear, cache_configure, cache_info

__version__ = "1.9.2"

__all__ = ("URL", "cache_clear", "cache_configure", "cache_info")
