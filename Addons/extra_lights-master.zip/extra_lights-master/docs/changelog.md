---
excerpt: The changes made to Scattershot over time.
nav_order: 2
nav_exclude: false
search_exclude: false
---

# Changelog

## v1.2
- Fixed issue with importing node groups on MacOS in Blender 3.4 
- Added documentation

## v1.1
- Updated for Blender 2.91
- Create Linked Sky now works in Eevee via the Hosek / Wilkie type
- Create Linked Sky now works in edge cases where the needed nodes are deleted before creation
