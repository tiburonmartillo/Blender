# Extra Lights
A plugin for Blender that adds physically based, photometric light presets to the Add menu.

For an extra 40+ presets, consider supporting the addon on the Blender Market: https://blendermarket.com/products/extra-lights

To get started using the add-on, **[read the documentation](https://jlampel.github.io/extra_lights/)**. 
